document.addEventListener('DOMContentLoaded', function() {
    const chatMessages = document.getElementById('chat-messages');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const clearChatButton = document.getElementById('clear-chat');
    
    // Game state for the chat
    let gameState = null;
    
    // Add a message to the chat
    function addMessage(content, isUser) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');
        messageDiv.classList.add(isUser ? 'user-message' : 'bot-message');
        
        const contentDiv = document.createElement('div');
        contentDiv.classList.add('message-content');
        contentDiv.textContent = content;
        
        const timeDiv = document.createElement('div');
        timeDiv.classList.add('message-time');
        timeDiv.textContent = getCurrentTime();
        
        messageDiv.appendChild(contentDiv);
        messageDiv.appendChild(timeDiv);
        chatMessages.appendChild(messageDiv);
        
        // Scroll to the bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Get current time in HH:MM format
    function getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    // Send message to the backend
    function sendMessage(message) {
        addMessage(message, true);
        userInput.value = '';
        
        // Show typing indicator
        showTypingIndicator();
        
        // Call the Python Flask API
        getBotResponse(message);
    }
    
    // Show typing indicator
    function showTypingIndicator() {
        const typingIndicator = document.createElement('div');
        typingIndicator.classList.add('message', 'bot-message');
        typingIndicator.id = 'typing-indicator';
        typingIndicator.innerHTML = '<div class="message-content"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>';
        chatMessages.appendChild(typingIndicator);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Remove typing indicator
    function removeTypingIndicator() {
        const indicator = document.getElementById('typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }
    
    // Get bot response from Python backend
    function getBotResponse(message) {
        // Add a small delay to make it feel more natural
        setTimeout(() => {
            // Call the Python Flask API
            fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    game_state: gameState
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Server error: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                removeTypingIndicator();
                if (data.status === 'success') {
                    addMessage(data.response, false);
                    gameState = data.game_state;
                } else {
                    addMessage('Sorry, something went wrong on the server!', false);
                    console.error('API Error:', data.error);
                }
            })
            .catch(error => {
                removeTypingIndicator();
                console.error('Network Error:', error);
                
                // Improved fallback responses
                const fallbackResponses = {
                    greetings: ["Hello! How can I help?", "Hi there!", "Greetings! Nice to meet you!"],
                    math: ["I can help with math! Try something like '2 + 3'"],
                    time: [`The current time is ${getCurrentTime()}.`],
                    jokes: [
                        "Why do programmers prefer dark mode? Because light attracts bugs!",
                        "How many programmers does it take to change a light bulb? None, that's a hardware problem!",
                        "Why don't scientists trust atoms? Because they make up everything!"
                    ],
                    farewells: ["Goodbye!", "See you later!", "Thanks for chatting!"],
                    default: [
                        "I'm having trouble connecting to my brain! But I'm still here to help.",
                        "Hmm, my servers are having a moment. Can you try that again?",
                        "I'm not sure I understand, but I'd love to help if you rephrase that!"
                    ]
                };
                
                // Enhanced keyword matching for fallback
                const msg = message.toLowerCase();
                if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey')) {
                    addMessage(fallbackResponses.greetings[Math.floor(Math.random() * fallbackResponses.greetings.length)], false);
                } else if (msg.includes('time') || msg.includes('clock')) {
                    addMessage(fallbackResponses.time[0], false);
                } else if (msg.includes('joke') || msg.includes('funny') || msg.includes('laugh')) {
                    addMessage(fallbackResponses.jokes[Math.floor(Math.random() * fallbackResponses.jokes.length)], false);
                } else if (msg.includes('bye') || msg.includes('goodbye') || msg.includes('see you')) {
                    addMessage(fallbackResponses.farewells[Math.floor(Math.random() * fallbackResponses.farewells.length)], false);
                } else if (msg.includes('add') || msg.includes('calculate') || msg.includes('math') || msg.includes('+')) {
                    // Simple addition fallback
                    if (msg.includes('+')) {
                        try {
                            const parts = msg.split('+');
                            if (parts.length === 2) {
                                const num1 = parseFloat(parts[0].trim());
                                const num2 = parseFloat(parts[1].trim());
                                if (!isNaN(num1) && !isNaN(num2)) {
                                    addMessage(`${num1} + ${num2} = ${num1 + num2}`, false);
                                    return;
                                }
                            }
                        } catch (e) {
                            // Fall through to default response
                        }
                    }
                    addMessage(fallbackResponses.math[0], false);
                } else {
                    addMessage(fallbackResponses.default[Math.floor(Math.random() * fallbackResponses.default.length)], false);
                }
            });
        }, 500 + Math.random() * 1000); // Random delay between 0.5-1.5 seconds
    }
    
    // Event listeners
    sendButton.addEventListener('click', () => {
        const message = userInput.value.trim();
        if (message) {
            sendMessage(message);
        }
    });
    
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const message = userInput.value.trim();
            if (message) {
                sendMessage(message);
            }
        }
    });
    
    clearChatButton.addEventListener('click', () => {
        chatMessages.innerHTML = '';
        gameState = null;
        addMessage("Hello again! How can I help you today?", false);
    });
    
    // Initial greeting
    addMessage("Hello! I'm Seeker, your helpful AI assistant. I can do math, tell jokes, play games, and more! How can I help you today?", false);
});
