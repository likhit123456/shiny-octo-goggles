import math
import random
import sys
import re
import datetime
import requests

# API Configuration
API_BASE_URL = "https://api.example.com/chatbot"  # Replace with actual API URL
API_KEY = "your_api_key_here"  # Replace with actual API key


class ChatbotAPI:
    @staticmethod
    def get_response(category, user_input=None):
        """Get response from API for a given category"""
        try:
            headers = {"Authorization": f"Bearer {API_KEY}"}
            params = {"category": category}
            if user_input:
                params["user_input"] = user_input

            response = requests.get(
                f"{API_BASE_URL}/responses",
                headers=headers,
                params=params,
                timeout=5
            )
            response.raise_for_status()
            data = response.json()
            return random.choice(data["replies"])

        except requests.exceptions.RequestException as e:
            # Fallback responses if API fails
            fallbacks = {
                "greetings": ["Hello! How can I help?"],
                "farewells": ["Goodbye!"],
                "default": ["I'm not sure I understand. Could you rephrase that?"],
                "math": ["I can help with math operations. Try asking me to calculate something."],
                "time": [f"The current time is {datetime.datetime.now().strftime('%H:%M')}."],
                "date": [f"Today is {datetime.datetime.now().strftime('%A, %B %d, %Y')}."],
                "jokes": ["Why do programmers prefer dark mode? Because light attracts bugs!"],
            }
            return random.choice(fallbacks.get(category, fallbacks["default"]))

    @staticmethod
    def get_math_operation(keyword):
        """Get math operation mapping from API"""
        try:
            headers = {"Authorization": f"Bearer {API_KEY}"}
            response = requests.get(
                f"{API_BASE_URL}/math_operations",
                headers=headers,
                params={"keyword": keyword},
                timeout=3
            )
            response.raise_for_status()
            return response.json().get("operation")

        except requests.exceptions.RequestException:
            # Fallback math operations if API fails
            math_ops = {
                "add": "add", "plus": "add", "+": "add",
                "subtract": "subtract", "minus": "subtract", "-": "subtract",
                "multiply": "multiply", "times": "multiply", "*": "multiply",
                "divide": "divide", "/": "divide",
                "square root": "square root", "sqrt": "square root",
                "factorial": "factorial", "!": "factorial",
                "natural log": "natural log", "ln": "natural log",
                "log base 10": "log base 10", "log": "log base 10",
                "area of triangle": "area of triangle",
                "area of square": "area of square",
                "area of rectangle": "area of rectangle",
                "area of circle": "area of circle"
            }
            return math_ops.get(keyword.lower())


def extract_numbers(input_str):
    return [float(num) for num in re.findall(r'-?\d+\.?\d*', input_str)]


def calculate(numbers=None, operation=None):
    try:
        if operation == "square root":
            if not numbers:
                return "Please provide a number"
            if numbers[0] < 0:
                return "Cannot calculate square root of negative number"
            return math.sqrt(numbers[0])

        elif operation == "area of square":
            if not numbers:
                return "Please enter a number."
            if numbers[0] < 0:
                return "The area cannot be negative."
            return numbers[0] * numbers[0]

        elif operation == "area of rectangle":
            if len(numbers) < 2:
                return "Please enter two values."
            if numbers[0] < 0 or numbers[1] < 0:
                return "Area of a rectangle cannot be negative."
            return numbers[0] * numbers[1]

        elif operation == "area of circle":
            if not numbers:
                return "Please enter a value."
            if numbers[0] < 0:
                return "Area cannot be negative."
            return math.pi * numbers[0] * numbers[0]

        elif operation == "area of triangle":
            if len(numbers) < 3:
                return "Please provide three side lengths"
            if any(side <= 0 for side in numbers[:3]):
                return "All sides must be positive"
            if not (numbers[0] + numbers[1] > numbers[2] and
                    numbers[0] + numbers[2] > numbers[1] and
                    numbers[1] + numbers[2] > numbers[0]):
                return "Invalid triangle sides"
            s = (numbers[0] + numbers[1] + numbers[2]) / 2
            return math.sqrt(s * (s - numbers[0]) * (s - numbers[1]) * (s - numbers[2]))

        elif operation == "factorial":
            if not numbers:
                return "Please provide a number"
            if numbers[0] < 0:
                return "Factorial requires non-negative integers"
            if not numbers[0].is_integer():  # Check if it's a whole number
                return "Factorial requires whole numbers (no decimals)"
            return math.factorial(int(numbers[0]))

        elif operation == "natural log":
            if not numbers:
                return "Please provide a number"
            if numbers[0] <= 0:
                return "Number must be positive"
            return math.log(numbers[0])

        elif operation == "log base 10":
            if not numbers:
                return "Please provide a number"
            if numbers[0] <= 0:
                return "Number must be positive"
            return math.log10(numbers[0])

        elif operation == "add":
            if len(numbers) < 2:
                return "Please provide two numbers"
            return sum(numbers)

        elif operation == "subtract":
            if len(numbers) < 2:
                return "Please provide two numbers"
            return numbers[0] - numbers[1]

        elif operation == "multiply":
            if len(numbers) < 2:
                return "Please provide two numbers"
            result = 1
            for num in numbers:
                result *= num
            return result

        elif operation == "divide":
            if len(numbers) < 2:
                return "Please provide two numbers"
            if numbers[1] == 0:
                return "Cannot divide by zero"
            return numbers[0] / numbers[1]

        return "Unknown operation"
    except (ValueError, TypeError):
        return "Invalid input - please provide valid numbers"


def get_current_time():
    """Get current time in HH:MM:SS format"""
    return datetime.datetime.now().strftime("%H:%M:%S")


def get_current_date():
    """Get current date in a readable format"""
    return datetime.datetime.now().strftime("%B %d, %Y")


def contains_keyword(user_input, keywords):
    return any(re.search(rf'\b{re.escape(kw)}\b', user_input.lower()) for kw in keywords)


def handle_math_query(user_input):
    numbers = extract_numbers(user_input)

    # Common math keywords to check
    math_keywords = [
        "add", "plus", "+", "subtract", "minus", "-",
        "multiply", "times", "*", "divide", "/",
        "square root", "sqrt", "factorial", "!",
        "natural log", "ln", "log base 10", "log",
        "area of triangle", "area of square",
        "area of rectangle", "area of circle"
    ]

    for kw in math_keywords:
        if contains_keyword(user_input, [kw]):
            operation = ChatbotAPI.get_math_operation(kw)
            if operation:
                result = calculate(numbers=numbers, operation=operation)

                if isinstance(result, str):
                    return result  # Return the error message directly
                else:
                    return f"The result is {result}"

    return "I didn't understand which math operation you wanted"


def handle_game(user_input, game_state=None):
    user_input = user_input.lower()

    if game_state is None:
        game_type = random.choice(["number_guess", "odd_even", "rps"])

        if game_type == "number_guess":
            game_state = {"type": "number_guess", "number": random.randint(1, 10)}
            return "I'm thinking of a number between 1 and 10. What's your guess?", game_state

        elif game_type == "odd_even":
            game_state = {"type": "odd_even", "number": random.randint(1, 100)}
            return "I have a number between 1 and 100. Is it odd or even?", game_state

        elif game_type == "rps":
            game_state = {"type": "rps", "choice": random.choice(["rock", "paper", "scissors"])}
            return "Let's play rock-paper-scissors! Type your choice (rock, paper, or scissors).", game_state

    else:
        if game_state["type"] == "number_guess":
            try:
                guess = int(user_input.strip())
                if guess == game_state["number"]:
                    return "🎉 You got it! Well done! The number was " + str(game_state["number"]) + ".", None
                elif guess < game_state["number"]:
                    return "📉 Too low! Try again.", game_state
                else:
                    return "📈 Too high! Try again.", game_state
            except ValueError:
                # Try to extract number from the input
                numbers = extract_numbers(user_input)
                if numbers:
                    guess = int(numbers[0])
                    if guess == game_state["number"]:
                        return "🎉 You got it! Well done! The number was " + str(game_state["number"]) + ".", None
                    elif guess < game_state["number"]:
                        return "📉 Too low! Try again.", game_state
                    else:
                        return "📈 Too high! Try again.", game_state
                else:
                    return "Please enter a number between 1 and 10.", game_state

        elif game_state["type"] == "odd_even":
            num = game_state["number"]
            correct = ("odd" if num % 2 else "even")

            if user_input in ["odd", "even"]:
                if user_input == correct:
                    return f"Correct! {num} is {correct}.", None
                else:
                    return f"Actually, {num} is {correct}. Better luck next time!", None
            else:
                return "Please guess either 'odd' or 'even'.", game_state

        elif game_state["type"] == "rps":
            choices = ["rock", "paper", "scissors"]
            if user_input not in choices:
                return "Please choose rock, paper, or scissors.", game_state

            bot_choice = game_state["choice"]
            user_choice = user_input

            if user_choice == bot_choice:
                return f"We both chose {user_choice}. It's a tie!", None
            elif ((user_choice == "rock" and bot_choice == "scissors") or
                  (user_choice == "paper" and bot_choice == "rock") or
                  (user_choice == "scissors" and bot_choice == "paper")):
                return f"You chose {user_choice} and I chose {bot_choice}. You win!", None
            else:
                return f"You chose {user_choice} and I chose {bot_choice}. I win!", None

    return "Let's play another time!", None


def get_response(user_input, game_state=None):
    user_input = user_input.lower().strip()

    # Define keyword categories
    categories = {
        "greetings": ["hello", "hi", "hey", "greetings", "good morning", "good afternoon"],
        "farewells": ["bye", "goodbye", "see you", "quit", "exit", "later", "cya"],
        "games": ["game", "play", "guess", "fun"],
        "time": ["time", "what time is it", "current time"],
        "date": ["date", "today's date", "what day is it"],
        "jokes": ["tell me a joke", "make me laugh", "joke", "say something funny", "knock knock"],
        "math": ["add", "subtract", "multiply", "divide", "square root", "factorial",
                 "log", "area", "triangle", "square", "rectangle", "circle"]
    }

    # Check for greetings first
    if contains_keyword(user_input, categories["greetings"]):
        return ChatbotAPI.get_response("greetings"), None

    # Check for farewells
    if contains_keyword(user_input, categories["farewells"]):
        return ChatbotAPI.get_response("farewells"), None

    # Handle active games first (if user is in the middle of a game)
    if game_state:
        return handle_game(user_input, game_state)

    # Handle new game requests
    if contains_keyword(user_input, categories["games"]):
        reply, new_game_state = handle_game(user_input)
        return reply, new_game_state

    # Check other categories
    if contains_keyword(user_input, categories["time"]):
        current_time = get_current_time()
        return f"The current time is {current_time}", None

    if contains_keyword(user_input, categories["date"]):
        current_date = get_current_date()
        return f"Today's date is {current_date}", None

    if contains_keyword(user_input, categories["jokes"]):
        return ChatbotAPI.get_response("jokes"), None

    if contains_keyword(user_input, categories["math"]):
        return handle_math_query(user_input), None

    # Default to general response
    return ChatbotAPI.get_response("default"), None


def main():
    print("Seeker 1.0: Hello! I'm your helpful chatbot. Type something to begin (or 'quit' to exit).")
    print("I can do math, tell jokes, play games, tell time, and more!")

    game_state = None

    while True:
        try:
            user_input = input("You: ").strip()
            if not user_input:
                print("Seeker: Don't be shy! Type something...")
                continue

            response, game_state = get_response(user_input, game_state)
            print("Seeker:", response)

            if contains_keyword(user_input, ["bye", "goodbye", "quit", "exit"]):
                sys.exit()
        except KeyboardInterrupt:
            print("\nSeeker: Goodbye!")
            sys.exit()
        except Exception as e:
            print(f"Seeker: Sorry, something went wrong. Error: {str(e)}")
            continue


if __name__ == "__main__":
    main()