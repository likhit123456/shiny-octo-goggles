#!/usr/bin/env python3
"""
Production server for Seeker Chatbot - optimized for deployment
"""
from flask import Flask, request, jsonify
import os
import sys
import traceback
from datetime import datetime

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import main
    print("✅ Successfully imported main.py")
except ImportError as e:
    print(f"❌ Error importing main.py: {e}")
    sys.exit(1)

app = Flask(__name__)

# Serve the main page
@app.route('/')
def home():
    try:
        with open('index.html', 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Seeker Chatbot</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body { 
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                    text-align: center; 
                    padding: 50px; 
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    min-height: 100vh;
                    margin: 0;
                }
                .container {
                    background: rgba(255,255,255,0.1);
                    padding: 40px;
                    border-radius: 20px;
                    backdrop-filter: blur(10px);
                    max-width: 600px;
                    margin: 0 auto;
                }
                h1 { color: #fff; margin-bottom: 20px; }
                .status { color: #ffeb3b; }
                .btn {
                    background: #4CAF50;
                    color: white;
                    padding: 15px 30px;
                    border: none;
                    border-radius: 25px;
                    font-size: 16px;
                    cursor: pointer;
                    margin: 10px;
                    text-decoration: none;
                    display: inline-block;
                }
                .btn:hover { background: #45a049; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🤖 Seeker Chatbot</h1>
                <p class="status">Welcome to the Seeker AI Chatbot!</p>
                <p>I can help you with math, games, jokes, and conversation.</p>
                <a href="/chat" class="btn">Start Chatting</a>
                <a href="/api/health" class="btn">Check Status</a>
            </div>
        </body>
        </html>
        """

# Serve static files
@app.route('/<path:filename>')
def serve_static(filename):
    try:
        if filename.endswith('.js'):
            with open(filename, 'r', encoding='utf-8') as f:
                response = app.response_class(
                    response=f.read(),
                    status=200,
                    mimetype='application/javascript'
                )
                return response
        elif filename.endswith('.css'):
            with open(filename, 'r', encoding='utf-8') as f:
                response = app.response_class(
                    response=f.read(),
                    status=200,
                    mimetype='text/css'
                )
                return response
        else:
            with open(filename, 'r', encoding='utf-8') as f:
                return f.read()
    except FileNotFoundError:
        return f"File not found: {filename}", 404

# Chat endpoint
@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        if not request.is_json:
            return jsonify({
                'status': 'error',
                'error': 'Request must be JSON'
            }), 400
        
        data = request.get_json()
        
        if 'message' not in data:
            return jsonify({
                'status': 'error',
                'error': 'Message field required'
            }), 400
        
        message = data['message'].strip()
        if not message:
            return jsonify({
                'status': 'error',
                'error': 'Message cannot be empty'
            }), 400
        
        game_state = data.get('game_state', None)
        
        # Get response from chatbot
        try:
            response, new_game_state = main.get_response(message, game_state)
            
            return jsonify({
                'status': 'success',
                'response': response,
                'game_state': new_game_state
            })
            
        except Exception as chatbot_error:
            print(f"Chatbot error: {chatbot_error}")
            return jsonify({
                'status': 'success',
                'response': f"I encountered an error processing your message. Please try again.",
                'game_state': None
            })
    
    except Exception as e:
        print(f"API error: {e}")
        return jsonify({
            'status': 'error',
            'error': 'Internal server error'
        }), 500

# Health check endpoint
@app.route('/api/health', methods=['GET'])
def health_check():
    try:
        # Test basic functionality
        test_response, _ = main.get_response("hello")
        
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '1.0',
            'features': ['chat', 'games', 'math', 'time', 'jokes'],
            'test_response': test_response
        })
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e)
        }), 500

# Alternative chat route for direct access
@app.route('/chat')
def chat_page():
    return home()

# About page
@app.route('/about')
def about():
    return jsonify({
        'name': 'Seeker Chatbot',
        'version': '1.0',
        'description': 'An AI chatbot with games, math, and conversation features',
        'features': [
            'Number guessing game',
            'Math calculations',
            'Time and date queries',
            'Jokes and conversation',
            'Rock-paper-scissors',
            'Odd/even guessing'
        ],
        'endpoints': {
            '/': 'Main chat interface',
            '/api/chat': 'Chat API endpoint',
            '/api/health': 'Health check',
            '/about': 'This information page'
        }
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        'status': 'error',
        'error': 'Endpoint not found'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'status': 'error',
        'error': 'Internal server error'
    }), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    
    print("=== SEEKER CHATBOT - PRODUCTION SERVER ===")
    print(f"🌐 Starting server on {host}:{port}")
    print("🚀 Ready for public access!")
    
    app.run(host=host, port=port, debug=False)
