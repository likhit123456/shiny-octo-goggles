# 🤖 SEEKER CHATBOT - USER GUIDE

## ✅ SYSTEM STATUS: READY TO RUN!

Your chatbot is fully functional and ready to use! All components have been tested and are working correctly.

## 🚀 HOW TO RUN YOUR CHATBOT

### Option 1: Web Interface (Recommended)
1. **Double-click** `start_server.bat` in your project folder
2. **Wait** for the message "Running on http://localhost:5000"
3. **Open** your web browser and go to: http://localhost:5000
4. **Start chatting** with Seeker!

### Option 2: Command Line Interface
1. **Open** Command Prompt
2. **Navigate** to your project folder:
   ```
   cd "c:\Users\likhi\OneDrive\Desktop\aiproject"
   ```
3. **Run** the chatbot:
   ```
   C:/Users/likhi/AppData/Local/Programs/Python/Python313/python.exe main.py
   ```

### Option 3: Manual Server Start
1. **Open** Command Prompt
2. **Navigate** to your project folder
3. **Run** the server:
   ```
   C:/Users/likhi/AppData/Local/Programs/Python/Python313/python.exe server.py
   ```
4. **Open** browser to: http://localhost:5000

## 🎯 FEATURES YOUR CHATBOT CAN DO

### 💬 **Chat & Conversation**
- Greetings: "hello", "hi", "hey"
- Farewells: "bye", "goodbye", "quit"
- Thanks: "thank you", "thanks"

### 🧮 **Math Operations**
- Addition: "2 + 3", "add 5 and 7"
- Subtraction: "10 - 3", "subtract 5 from 10"
- Multiplication: "4 * 5", "multiply 6 by 7"
- Division: "20 / 4", "divide 15 by 3"
- Square root: "square root of 16"
- Factorial: "factorial of 5"
- Area calculations: "area of circle with radius 5"

### 🕐 **Time & Date**
- Current time: "what time is it"
- Current date: "what's today's date"

### 😄 **Entertainment**
- Jokes: "tell me a joke"
- Games: "let's play a game"

### 🌐 **API Endpoints**
Your chatbot also provides REST API endpoints:
- `POST /api/chat` - Chat with the bot
- `POST /api/math` - Math calculations
- `GET /api/time` - Get current time/date
- `GET /api/health` - Health check

## 📁 PROJECT FILES

```
aiproject/
├── main.py              # Core chatbot logic
├── server.py            # Flask web server
├── index.html           # Web interface
├── script_fixed.js      # Frontend JavaScript
├── styles.css           # Web styling
├── start_server.bat     # Easy server launcher
└── test_system.py       # System tests
```

## 🔧 TROUBLESHOOTING

### If the web interface doesn't work:
1. Make sure no other programs are using port 5000
2. Check that Flask is installed: `pip install flask`
3. Try restarting the server

### If you get import errors:
1. Make sure all files are in the same folder
2. Check that Python is properly installed

### If calculations don't work:
1. Use clear math expressions like "2 + 3"
2. Include spaces around operators when possible

## 💡 EXAMPLE CONVERSATIONS

**User:** hello
**Seeker:** Hello! How can I help you today?

**User:** calculate 15 + 25
**Seeker:** The result is 40

**User:** what time is it
**Seeker:** The current time is 15:30:45

**User:** tell me a joke
**Seeker:** Why don't scientists trust atoms? Because they make up everything!

**User:** square root of 64
**Seeker:** The result is 8.0

## 🎉 ENJOY YOUR CHATBOT!

Your Seeker chatbot is now ready to help with math, answer questions, tell jokes, and more. Have fun chatting!
